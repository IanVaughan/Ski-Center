//---------------------------------------------------------------------------
#ifndef MVC_ModelH
#define MVC_ModelH
//---------------------------------------------------------------------------

class MVC_Model
{
public:

    typedef struct
    {
        TColor kColor;
        String kText;
    }LessonIndex;

    void SetLesson(LessonIndex tLessonData) {} ;
    LessonIndex GetLesson() {} ;


/*    void SetCellColor(int iCol, int iRow, TColor kColor);
    TColor GetCellColor(int iCol, int iRow);

    void SetCellText(int iCol, int iRow, String kText);
    String GetCellText(int iCol, int iRow);*/

private:


//    LessonColorIndex *tLCI[MAX_COL][MAX_ROW];




};
//------------------------------------------------------------------------------
#endif
