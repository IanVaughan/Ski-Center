//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "MVC_ModelLayoutLessons.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
