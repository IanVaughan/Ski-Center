//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "LessonBookingSheetSrc.h"
#include "BookingSheetUtils.h"
//#include "vcl/sysdefs.h" //date/time

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TLessonBookingSheet *LessonBookingSheet;
//---------------------------------------------------------------------------

__fastcall TLessonBookingSheet::TLessonBookingSheet(TComponent* Owner) : TForm(Owner)
{
    m_pkBookingSheetUtils = new BookingSheetUtils(LessonSG);

    weekSelector->Tabs->Add("Monday");
    weekSelector->Tabs->Add("Tuesday");
    weekSelector->Tabs->Add("Wednesday");
    weekSelector->Tabs->Add("Thursday");
    weekSelector->Tabs->Add("Friday");
    weekSelector->Tabs->Add("Saturday");
    weekSelector->Tabs->Add("Sunday");

//    TDateTime *Date;
//    DateTimePicker->Date = Date->CurrentDate();
}
//---------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::FormDestroy(TObject *Sender)
{
    delete m_pkBookingSheetUtils;
}
//---------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::FormResize(TObject *Sender)
{
    double dWidth = ClientWidth / LessonSG->ColCount; //NUM_ROWS;
    LessonSG->DefaultColWidth = dWidth-1.5;//ClientWidth/10 -2;
    weekSelector->TabWidth = ClientWidth/7 -1;
}
//---------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::weekSelectorChange(TObject *Sender)
{
    for(int i=1; i< LessonSG->RowCount; i++)
        for(int j=0; j< LessonSG->ColCount; j++)
            LessonSG->Cells[j][i] = "";

//    int index = weekSelector->TabIndex;
    //LoadDow(index);
}
//---------------------------------------------------------------------------

bool TLessonBookingSheet::SaveAll()
{
    //save instructors time/days etc
    //save the changes
    TStringList *list = new TStringList;
    String name;

    for (int i=0; i < LessonSG->RowCount; i++)
    {
        if(!m_pkBookingSheetUtils->RowEven(i))
        for (int j=0; j < LessonSG->ColCount; j++)
        {
            name = LessonSG->Cells[j][i];

            //add time on
            //name = (String)j +" - " + name;
            list->Add(name);
        }
    }

    name = m_pkBookingSheetUtils->GetStringDOW(weekSelector->TabIndex) + ".ins";

    list->SaveToFile("Instructors\\"+name);

    delete list;

    return true;
}
// -----------------------------------------------------------------------------

/*bool TbookingSheet::LoadDow(BookingSheetUtils::DayOfWeek dow)
{
/*    char days[7][10] = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
    TDateTime dtDate = StrToDate(Edit1->Text);
    ShowMessage(Edit1->Text + AnsiString(" is a ") + days[dtDate.DayOfWeek()]);*/
/*
    String filename = GetStringDOW(dow);

    filename = "Instructors\\"+ filename + ".ins";

    bool yes = FileExists(filename);
    if(!yes)
    {
        int ans = Application->MessageBox("That day of the week file was not found, perhaps it wasnt saved!\nDo you want to create one now, if you dont one will get created as soon as a change is made anyway.", "File not found", MB_YESNO|MB_ICONQUESTION);
        if(ans == ID_YES)
        {
            TStringList *list = new TStringList;
            list->SaveToFile(filename);
            delete list;
        }
        else
            return false;
    }

    TStringList *list = new TStringList;
    list->LoadFromFile(filename);

    //load in times and intructors booked in
    String name;

    int col = 0;
    int row = 0;

    for(int i=0; i< list->Count; i++)
    {
        name = list->Strings[i];

        LessonSG->Cells[col][row] = name;

        if(col < 9)
            col++;
        else
        {
            col = 0;

            if(row <= 0)
                row ++;
            else
                row+=2;
        }
    }

    return true;
}
// -----------------------------------------------------------------------------
*/

//only allow min & max form sizes
void __fastcall TLessonBookingSheet::WMGetMinMaxInfo(TWMGetMinMaxInfo &Msg)
{
    Msg.MinMaxInfo->ptMinTrackSize.x=443; //ptMinTrackSize = min size allowed
    Msg.MinMaxInfo->ptMinTrackSize.y=450;//500; //by dragging with the mouse.

    Msg.MinMaxInfo->ptMaxTrackSize.x=933; //ptMaxTrackSize = max size allowed
    Msg.MinMaxInfo->ptMaxTrackSize.y=752; //by dragging with the mouse
}
//------------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::WeekChangerSBChange(TObject *Sender)
{
    WeekChangerSB->Position = 5;    
}
//---------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::LessonSGDrawCell(TObject *Sender,
      int Col, int Row, TRect &Rect, TGridDrawState State)
{
    TCanvas *canvas = LessonSG->Canvas;

    bool bSelected = (Col == LessonSG->Col && Row == LessonSG->Row);

    if(bSelected)
    {
        canvas->Brush->Color = clBlue;
        canvas->Font->Color = clWhite;
    }
    //else no select
    else
    {
        canvas->Brush->Color = m_pkBookingSheetUtils->GetCellColor(Col, Row);
    }

    //the first row is fixed
    if(Row == 0)
    {
        canvas->Brush->Color = clLtGray;
    }

    canvas->Font->Color = clBlack;

    canvas->FillRect(Rect);
    canvas->TextOut(Rect.Left+3, Rect.Top+3, LessonSG->Cells[Col][Row]);
//    canvas->TextOut(Rect.Left+3, Rect.Top+3, m_pkBookingSheetUtils->GetCellText(Col, Row));

    if (State.Contains(gdSelected))
    {
        canvas->Brush->Color = clBlue;
        canvas->FillRect(Rect);
        //canvas->DrawFocusRect(Rect);
        canvas->Font->Color = clWhite;
        canvas->TextOut(Rect.Left+3, Rect.Top+3, LessonSG->Cells[Col][Row]);
    }
}
//---------------------------------------------------------------------------

