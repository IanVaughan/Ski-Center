//---------------------------------------------------------------------------
#ifndef MVCControlerH
#define MVCControlerH
//---------------------------------------------------------------------------

class MVC_Model;

class MVCControler
{
    TStringList *m_pkUsersList;

    MVC_Model *pkModel;

public:
    MVCControler();
    ~MVCControler();

    bool LoadLoginFile();
    bool ValidLogin(String userName, String userPassword);

    bool ShowForm(TForm *pkForm);

};
//------------------------------------------------------------------------------
#endif
 