//---------------------------------------------------------------------------
#ifndef MVC_ModelLayoutTimeH
#define MVC_ModelLayoutTimeH
//---------------------------------------------------------------------------

class MVC_ModelLayoutTime
{
    typedef struct _LessonTimes
    {
        String kStartTime;
        String kEndTime;
        String kBreak;
        _LessonTimes *Next;
    }LessonTimesData;
    TList *LessonTimes;

};
//------------------------------------------------------------------------------
#endif
 