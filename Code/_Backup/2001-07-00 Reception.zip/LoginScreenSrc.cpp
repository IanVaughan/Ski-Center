//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "LoginScreenSrc.h"
#include "LessonBookingSheetSrc.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TLoginScreen *LoginScreen;
//---------------------------------------------------------------------------

__fastcall TLoginScreen::TLoginScreen(TComponent* Owner) : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TLoginScreen::closeBTNClick(TObject *Sender)
{
    m_bCanClose = true;
    Close();
}
//---------------------------------------------------------------------------

void __fastcall TLoginScreen::okBTNClick(TObject *Sender)
{
    if(ValidLogin(userNameEdit->Text, passwordEdit->Text))
    {
        OkToRun();
    }
    else
    {
        Application->MessageBox("Either the User Name or the Password are incorrect.\nPlease check your User Name and reenter your password.\n(Note: They are NOT case sensitive)","Cannot Login", MB_OK|MB_ICONWARNING);
        //select all off the current password
        passwordEdit->SetFocus();
        passwordEdit->SelStart = 0;
        passwordEdit->SelLength = passwordEdit->Text.Length();
    }
}
//---------------------------------------------------------------------------

bool TLoginScreen::ValidLogin(String userName, String userPassword)
{
    bool bFound = false;

    //loop round all password lines
    for(int i=0; i<usersList->Count; i++)
    {
        //if we find a match with the user name
        if(usersList->Strings[i] == userName)
        {
            //check if the user name has the password on the next line
            if(i < usersList->Count-1)
            if(usersList->Strings[i+1] == userPassword)
            {
                bFound = true;
                break;
            }
        }
    }

    return bFound;
}
//---------------------------------------------------------------------------

void TLoginScreen::OkToRun()
{
    Hide();
    LessonBookingSheet->ShowModal();
    Show();
}
//---------------------------------------------------------------------------

void __fastcall TLoginScreen::FormCloseQuery(TObject *Sender, bool &CanClose)
{
    CanClose = m_bCanClose;
}
//---------------------------------------------------------------------------

void __fastcall TLoginScreen::FormShow(TObject *Sender)
{
    userNameEdit->SetFocus();
    userNameEdit->Text = "";
    passwordEdit->Text = "";

    m_bCanClose = false;

    
    if(FileExists("Password.csc"))
    {
        usersList = new TStringList;
        usersList->LoadFromFile("Password.csc");
    }
    else
    {
        Application->MessageBox("The file containing the Booking System Password List can not be found in the Booking System folder.\nThis is a critial file needed to run, so the program will now shutdown.\nPlease contact the System Administrator for more help.","Password file not found", MB_OK|MB_ICONWARNING);
        //Application->Terminate();
        m_bCanClose = true;
        Close();
    }
}
//---------------------------------------------------------------------------

void __fastcall TLoginScreen::FormHide(TObject *Sender)
{
    //delete and create on show/hide of form, not only save mem, but no mem hacks for password
    delete usersList;
}
//---------------------------------------------------------------------------

void __fastcall TLoginScreen::BitBtn1Click(TObject *Sender)
{
//  usersst->Add(userName->Text);
//  usersList->Add(password->Text);
}
//---------------------------------------------------------------------------

