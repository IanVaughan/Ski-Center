//---------------------------------------------------------------------------
#ifndef instructorSrcH
#define instructorSrcH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <Menus.hpp>
//---------------------------------------------------------------------------
class TinstructorForm : public TForm
{
__published:	// IDE-managed Components
    TListBox *instructorList;
    TBitBtn *SaveAsBTN;
    TBitBtn *BitBtn2;
    TPopupMenu *PopupMenu1;
    TMenuItem *AddMI;
    TMenuItem *EditMI;
    TMenuItem *DeleteMI;
    TBitBtn *SaveOnceBTN;
    void __fastcall instructorListClick(TObject *Sender);
    
    void __fastcall AddMIClick(TObject *Sender);
    void __fastcall EditMIClick(TObject *Sender);
    void __fastcall DeleteMIClick(TObject *Sender);
    void __fastcall instructorListDblClick(TObject *Sender);
    void __fastcall SaveAsBTNClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall PopupMenu1Popup(TObject *Sender);
    void __fastcall SaveOnceBTNClick(TObject *Sender);
private:	// User declarations

public:		// User declarations
    __fastcall TinstructorForm(TComponent* Owner);

    String GetSelectedName();
};
//---------------------------------------------------------------------------
extern PACKAGE TinstructorForm *instructorForm;
//---------------------------------------------------------------------------
#endif
