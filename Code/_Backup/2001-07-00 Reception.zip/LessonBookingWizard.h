//---------------------------------------------------------------------------
#ifndef LessonBookingWizardH
#define LessonBookingWizardH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "C:\Program Files\Borland\CBuilder3\Components\xgrid20\XStringGrid.hpp"
#include <Buttons.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TLessonBookingWiz : public TForm
{
__published:
    TNotebook *lessonWizardNB;
    TBevel *Bevel6;
    TBevel *Bevel7;
    TLabel *Label11;
    TPanel *pickSki;
    TPanel *pickBoard;
    TPanel *pickBlade;
    TScrollBar *ScrollBar1;
    TPanel *lessonPanel;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label13;
    TLabel *Label12;
    TLabel *Label14;
    TLabel *Label9;
    TLabel *Label10;
    TBevel *Bevel1;
    TBevel *Bevel5;
    TBevel *Bevel4;
    TBevel *Bevel8;
    TBevel *Bevel9;
    TPanel *pickLI;
    TPanel *pickMB;
    TPanel *pickMT;
    TPanel *pickPrivate;
    TPanel *pickUI;
    TPanel *pickEP;
    TPanel *topPanel;
    TLabel *Label4;
    TLabel *Adults;
    TLabel *Label5;
    TBevel *Bevel3;
    TLabel *Label16;
    TLabel *Label17;
    TLabel *Label18;
    TLabel *Label19;
    TLabel *Label8;
    TUpDown *UpDown1;
    TUpDown *UpDown2;
    TComboBox *peopleAdult;
    TComboBox *peopleChild;
    TXStringGrid *customersOnLessonGrid;
    TLabel *Label23;
    TLabel *Label24;
    TLabel *Label25;
    TLabel *Label26;
    TLabel *Label27;
    TLabel *Label28;
    TLabel *Label29;
    TBevel *Bevel10;
    TDateTimePicker *DateTimePicker1;
    TDateTimePicker *DateTimePicker2;
    TDateTimePicker *DateTimePicker3;
    TDateTimePicker *DateTimePicker4;
    TDateTimePicker *DateTimePicker5;
    TDateTimePicker *DateTimePicker6;
    TDateTimePicker *DateTimePicker7;
    TDateTimePicker *DateTimePicker8;
    TComboBox *lessonLayout;
    TDateTimePicker *DateTimePicker9;
    TDateTimePicker *DateTimePicker10;
    TDateTimePicker *DateTimePicker11;
    TDateTimePicker *DateTimePicker12;
    TBitBtn *BitBtn1;
    TLabel *Label6;
    TLabel *Label7;
    TLabel *Label15;
    TLabel *Label20;
    TMemo *Memo1;
    TBitBtn *printBTN;
    TBitBtn *confirmBTN;
    TBitBtn *addNotes;
    TBevel *Bevel2;
    TBitBtn *saveBTN;
    TBitBtn *cancelBTN;
    TBitBtn *lastBTN;
    TBitBtn *nextBTN;
    TLabel *Label21;
    TLabel *Label22;
    TLabel *Label30;
    TLabel *Label31;
    TLabel *Label32;
    TLabel *Label33;
    void __fastcall pickSkiClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall pickMTClick(TObject *Sender);
    void __fastcall lastBTNClick(TObject *Sender);
    void __fastcall nextBTNClick(TObject *Sender);
    void __fastcall confirmBTNClick(TObject *Sender);
    void __fastcall ScrollBar1Change(TObject *Sender);
    void __fastcall cancelBTNClick(TObject *Sender);
    void __fastcall saveBTNClick(TObject *Sender);

    void __fastcall peopleAdultChange(TObject *Sender);
private:
    typedef enum {atSki, atBoard, atBlade, atNone} ActivityType;
    typedef enum {sltMT, sltMB, sltLI, sltUI, sltEP, sltPrivate, sltNone} SkiLessonType;
//    typedef enum {bltSBT, bltSBC, bltSBCLI, bltPrivate, bltNone} BoardLessonType;
//    typedef enum {sbltPrivate, sbltNone} BladeLessonType;

    ActivityType ActivtySet;
    SkiLessonType SkiLessonSet;
//    BoardLessonType BoardLessonSet;
//    BladeLessonType BladeLessonSet;

public:
    __fastcall TLessonBookingWiz(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TLessonBookingWiz *LessonBookingWiz;
//---------------------------------------------------------------------------
#endif
