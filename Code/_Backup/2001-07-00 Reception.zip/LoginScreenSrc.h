//---------------------------------------------------------------------------
#ifndef LoginScreenSrcH
#define LoginScreenSrcH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TLoginScreen : public TForm
{
__published:	// IDE-managed Components
    TEdit *userNameEdit;
    TEdit *passwordEdit;
    TLabel *Label1;
    TLabel *Label2;
    TBitBtn *okBTN;
    TBitBtn *closeBTN;
    TBevel *Bevel1;
    TImage *Image1;
    TImage *Image2;
    TBitBtn *BitBtn1;
    void __fastcall closeBTNClick(TObject *Sender);
    void __fastcall okBTNClick(TObject *Sender);
    void __fastcall FormCloseQuery(TObject *Sender, bool &CanClose);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall FormHide(TObject *Sender);

    void __fastcall BitBtn1Click(TObject *Sender);
private:
    bool ValidLogin(String name, String password);
    void OkToRun();

    bool NameInFile(String name, String &password);

    TStringList *usersList;// = new TStringList;

    bool m_bCanClose;

public:		// User declarations
    __fastcall TLoginScreen(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TLoginScreen *LoginScreen;
//---------------------------------------------------------------------------
#endif
