//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "searchFor.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
Tsearch *search;
//---------------------------------------------------------------------------
__fastcall Tsearch::Tsearch(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall Tsearch::Button2Click(TObject *Sender)
{
    Close();    
}
//---------------------------------------------------------------------------

