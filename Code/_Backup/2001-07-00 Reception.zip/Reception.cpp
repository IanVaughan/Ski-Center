//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("Reception.res");
USEFORM("LoginScreenSrc.cpp", LoginScreen);
USEFORM("LessonBookingSheetSrc.cpp", LessonBookingSheet);
USEUNIT("BookingSheetUtils.cpp");
USEFORM("quickLessonBookingSrc.cpp", QuickLessonBooking);
USEFORM("LessonBookingWizard.cpp", LessonBookingWiz);
USEFORM("instructorSrc.cpp", instructorForm);
USEFORM("InstructorNameSrc.cpp", InstructorNameEdit);
USEFORM("searchFor.cpp", search);
USEFORM("help.cpp", helpForm);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
    try
    {
        Application->Initialize();
        Application->Title = "Booking System";
        Application->CreateForm(__classid(TLoginScreen), &LoginScreen);
        Application->CreateForm(__classid(TLessonBookingSheet), &LessonBookingSheet);
        Application->CreateForm(__classid(ThelpForm), &helpForm);
        Application->CreateForm(__classid(TInstructorNameEdit), &InstructorNameEdit);
        Application->CreateForm(__classid(TinstructorForm), &instructorForm);
        Application->CreateForm(__classid(TLessonBookingWiz), &LessonBookingWiz);
        Application->CreateForm(__classid(TQuickLessonBooking), &QuickLessonBooking);
        Application->CreateForm(__classid(Tsearch), &search);
        Application->Run();
    }
    catch (Exception &exception)
    {
        Application->ShowException(&exception);
    }
    return 0;
}
//---------------------------------------------------------------------------
