//---------------------------------------------------------------------------
#ifndef bookingSheetUtilsH
#define bookingSheetUtilsH
//#include "C:\Program Files\Borland\CBuilder3\Components\xgrid20\XStringGrid.hpp"
#include "XStringGrid.hpp"
//---------------------------------------------------------------------------
class BookingSheetUtils
{
private:
    TXStringGrid *m_pkLessonXTG;

protected:

public:
  __fastcall BookingSheetUtils(TXStringGrid *pointer) {m_pkLessonXTG = pointer;};
  __fastcall ~BookingSheetUtils() {};

    bool RowEven(int rowNum);

    bool LessonBooked(int col = -1, int row = -1);
    bool InstructorBooked(int col = -1, int row = -1);

    bool SetRowHeights();

    typedef enum {dowMonday, dowTuesday, dowWednesday, dowThursday, dowFriday, dowSaturday, dowSunday} DayOfWeek;
    String GetStringDOW(DayOfWeek dow);
    DayOfWeek GetDOW(String dow);
 
};
//---------------------------------------------------------------------------
#endif
