//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "LessonBookingSheetSrc.h"
#include "instructorSrc.h"
#include "LessonBookingWizard.h"
#include "quickLessonBookingSrc.h"
#include "BookingSheetUtils.h"
#include "help.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "XStringGrid"
#pragma resource "*.dfm"
TLessonBookingSheet *LessonBookingSheet;
//---------------------------------------------------------------------------

int NUM_ROWS = 10;
//int SelectedCol;
//int SelectedRow;

__fastcall TLessonBookingSheet::TLessonBookingSheet(TComponent* Owner) : TForm(Owner)
{
    m_pkBookingSheetUtils = new BookingSheetUtils(LessonXSG);

    m_pkBookingSheetUtils->SetRowHeights();

    weekSelector->Tabs->Add("Monday");
    weekSelector->Tabs->Add("Tuesday");
    weekSelector->Tabs->Add("Wednesday");
    weekSelector->Tabs->Add("Thursday");
    weekSelector->Tabs->Add("Friday");
    weekSelector->Tabs->Add("Saturday");
    weekSelector->Tabs->Add("Sunday");

//    DateTimePicker->Date = GetDate();

    bookedRow = -1;
    bookedCol = -1;
}
//---------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::FormDestroy(TObject *Sender)
{
    delete m_pkBookingSheetUtils;
}
//---------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::FormResize(TObject *Sender)
{
    double dWidth = ClientWidth/NUM_ROWS;
    LessonXSG->DefaultColWidth = dWidth-1.5;//ClientWidth/10 -2;
    weekSelector->TabWidth = (ClientWidth/7) -(10);
}
//---------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::SetInstructorClick(TObject *Sender)
{
    if(instructorForm->ShowModal() == mrOk)
    {
        String name = instructorForm->GetSelectedName();

        TGridRect myRect;
        myRect = LessonXSG->Selection;

        for (int i=myRect.Left; i <= myRect.Right; i++)
        {
            LessonXSG->Cells[i][LessonXSG->Row] = name;
        }
    }
    SaveAll();
}
//---------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::ChangeInstructorClick(TObject *Sender)
{
    SetInstructorClick(this);
}
//---------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::ClearInstrcutorClick(TObject *Sender)
{
    TGridRect myRect;
    myRect = LessonXSG->Selection;

    for (int i=myRect.Left; i <= myRect.Right; i++)
        LessonXSG->Cells[i][LessonXSG->Row] = "";

    SaveAll();
}
//---------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::CreateLessonClick(TObject *Sender)
{
    LessonBookingWiz->ShowModal();
//    LessonXSG->Cells[LessonXSG->Col][LessonXSG->Row] = "test";
}
//---------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::LessonBookingWizard1Click(TObject *Sender)
{
    LessonBookingWiz->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::NormalLessonBooking1Click(TObject *Sender)
{
    if(QuickLessonBooking->ShowModal() == mrOk)
    {
        LessonXSG->Cells[LessonXSG->Col][LessonXSG->Row] = "Booked";
    }
}
//---------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::Exit1Click(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::weekSelectorChange(TObject *Sender)
{
    for(int i=1; i< LessonXSG->RowCount; i++)
        for(int j=0; j< LessonXSG->ColCount; j++)
            LessonXSG->Cells[j][i] = "";

    int index = weekSelector->TabIndex;
    //LoadDow(index);
}
//---------------------------------------------------------------------------

bool TLessonBookingSheet::SaveAll()
{
    //save instructors time/days etc
    //save the changes
    TStringList *list = new TStringList;
    String name;

    for (int i=0; i < LessonXSG->RowCount; i++)
    {
        if(!m_pkBookingSheetUtils->RowEven(i))
        for (int j=0; j < LessonXSG->ColCount; j++)
        {
            name = LessonXSG->Cells[j][i];

            //add time on
            //name = (String)j +" - " + name;
            list->Add(name);
        }
    }

    name = m_pkBookingSheetUtils->GetStringDOW(weekSelector->TabIndex) + ".ins";

    list->SaveToFile("Instructors\\"+name);

    delete list;

    return true;
}
// -----------------------------------------------------------------------------

/*bool TbookingSheet::LoadDow(BookingSheetUtils::DayOfWeek dow)
{
/*    char days[7][10] = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
    TDateTime dtDate = StrToDate(Edit1->Text);
    ShowMessage(Edit1->Text + AnsiString(" is a ") + days[dtDate.DayOfWeek()]);*/
/*
    String filename = GetStringDOW(dow);

    filename = "Instructors\\"+ filename + ".ins";

    bool yes = FileExists(filename);
    if(!yes)
    {
        int ans = Application->MessageBox("That day of the week file was not found, perhaps it wasnt saved!\nDo you want to create one now, if you dont one will get created as soon as a change is made anyway.", "File not found", MB_YESNO|MB_ICONQUESTION);
        if(ans == ID_YES)
        {
            TStringList *list = new TStringList;
            list->SaveToFile(filename);
            delete list;
        }
        else
            return false;
    }

    TStringList *list = new TStringList;
    list->LoadFromFile(filename);

    //load in times and intructors booked in
    String name;

    int col = 0;
    int row = 0;

    for(int i=0; i< list->Count; i++)
    {
        name = list->Strings[i];

        LessonXSG->Cells[col][row] = name;

        if(col < 9)
            col++;
        else
        {
            col = 0;

            if(row <= 0)
                row ++;
            else
                row+=2;
        }
    }

    return true;
}
// -----------------------------------------------------------------------------
*/
void __fastcall TLessonBookingSheet::bookingWizardBTNClick(TObject *Sender)
{
    if(m_pkBookingSheetUtils->InstructorBooked())
    {
        LessonBookingWiz->ShowModal();
    }
    else
    {
        Application->MessageBox("No instructor is set, you cannot book a lesson here.\nAdmin users, to add an instructor, move selection to the box above, right click and add an instructor.", "No Instructor Set", MB_ICONINFORMATION|MB_OK);
    }
}
//---------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::AboutMIClick(TObject *Sender)
{
    helpForm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::LessonXSGMouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
    //when auto selecting cell, the selection is lose, so save it
    TGridRect myRect;
	myRect = LessonXSG->Selection;

    // Auto select cell on right click context menu show
    //get cell mouse click was in
    int ACol;
    int ARow;
    LessonXSG->MouseToCell(X, Y, ACol, ARow);

    if(ACol == -1 || ARow == -1) return;

    //if right clicked inside selection
    if(ACol >= myRect.Left && ACol <= myRect.Right && ARow >= myRect.Top && ARow <= myRect.Bottom)
    {
        //set the selected cell to the one found under the mouse
        LessonXSG->Selection = myRect;
    }
    else
    {
        if(ARow == 0)
        {
            TGridRect myRect;
	        myRect.Left =  ACol;
            myRect.Top =  0;
            myRect.Right =  ACol;
            myRect.Bottom = NUM_ROWS;
            LessonXSG->Selection = myRect;
        }
        else
        {
            LessonXSG->Col = ACol;
            LessonXSG->Row = ARow;
        }
    }

/*    //now show the correct menu type, Lesson or Instructor
    if(ARow == 0)
        LessonXSG->PopupMenu = columnPU;
    else if(m_pkBookingSheetUtils->RowEven(LessonXSG->Row))
        LessonXSG->PopupMenu = lessonPopup;
    else
        LessonXSG->PopupMenu = instructorPopup;*/
}
//---------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::LessonXSGDblClick(TObject *Sender)
{
    if(!m_pkBookingSheetUtils->RowEven(m_iCurrentRow))
    {
/*        TGridRect myRect;
	    myRect.Left =  0;
        myRect.Top =  LessonXSG->Row;
        myRect.Right =  NUM_ROWS;
        myRect.Bottom = LessonXSG->Row;
        LessonXSG->Selection = myRect;
*/
        SetInstructorClick(this);
    }
    else
    {
        if(m_pkBookingSheetUtils->InstructorBooked())
        {
            if(QuickLessonBooking->ShowModal() == mrOk)
            {
                LessonXSG->Cells[LessonXSG->Col][LessonXSG->Row] = "Mixed Beginner";

                bookedRow = LessonXSG->Row;
                bookedCol = LessonXSG->Col;
            }
        }
    }
}
//---------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::LessonXSGClick(TObject *Sender)
{
    m_iCurrentRow = LessonXSG->Row;

    //now show the correct menu type, Lesson or Instructor
    if(m_iCurrentRow == 0)
    {
        LessonXSG->PopupMenu = columnPU;
    }
    else if(m_pkBookingSheetUtils->RowEven(m_iCurrentRow))
    {
        LessonXSG->PopupMenu = lessonPopup;

        normalLessonBookingBTN->Enabled = true;
        LessonBookingWizardBTN->Enabled = true;
    }
    else
    {
        LessonXSG->PopupMenu = instructorPopup;

        normalLessonBookingBTN->Enabled = false;
        LessonBookingWizardBTN->Enabled = false;
    }
}
//---------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::LessonXSGMouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y)
{
    //select correct hint
    LessonXSG->Hint = "";

    int ACol;
    int ARow;
    LessonXSG->MouseToCell(X, Y, ACol, ARow);

    if(m_pkBookingSheetUtils->LessonBooked(ACol, ARow))
    {
        LessonXSG->Hint = "No Lesson, double click to create one.";
    }
    else if(m_pkBookingSheetUtils->InstructorBooked(ACol, ARow))
    {
        LessonXSG->Hint = "No Instructor, right click to set one.";
    }
    else
        LessonXSG->Hint = "";

    Application->ShowHint = true;
    
}
//---------------------------------------------------------------------------

//only allow min & max form sizes
void __fastcall TLessonBookingSheet::WMGetMinMaxInfo(TWMGetMinMaxInfo &Msg)
{
    Msg.MinMaxInfo->ptMinTrackSize.x=443; //ptMinTrackSize = min size allowed
    Msg.MinMaxInfo->ptMinTrackSize.y=450;//500; //by dragging with the mouse.

    Msg.MinMaxInfo->ptMaxTrackSize.x=933; //ptMaxTrackSize = max size allowed
    Msg.MinMaxInfo->ptMaxTrackSize.y=752; //by dragging with the mouse
}
//------------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::LessonXSGDrawCell(TObject *Sender,
      int Col, int Row, TRect &Rect, TGridDrawState State)
{
    TCanvas *canvas = LessonXSG->Canvas;

    bool bSelected = (Col == LessonXSG->Col && Row == LessonXSG->Row);//(Row == RowSelected || Row == RowRowReleased);

    canvas->Font->Color = clBlack;

    //if we want to set the cell color
    if(Col == bookedCol && Row == bookedRow)
    {
        canvas->Font->Color = clWhite;
        //canvas->Font->Style = fsBold;

        canvas->Brush->Color = clGreen;
    }
    //else uif its just a mouse select
    else if(bSelected)
    {
        canvas->Brush->Color = clBlue;
        canvas->Font->Color = clWhite;
    }
    //else no select
    else
    {
        canvas->Brush->Color = clWhite;
    }

    //the first row is fixed
    if(Row ==0)
    {
        canvas->Brush->Color = clLtGray;
    }

    canvas->FillRect(Rect);
    canvas->TextOut(Rect.Left+3, Rect.Top+3, LessonXSG->Cells[Col][Row]);

    if (State.Contains(gdSelected))
    {
        canvas->Brush->Color = clBlue;
        canvas->FillRect(Rect);
        //canvas->DrawFocusRect(Rect);
        canvas->Font->Color = clWhite;
        canvas->TextOut(Rect.Left+3, Rect.Top+3, LessonXSG->Cells[Col][Row]);
    }
}
//---------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::normalLessonBookingBTNClick(TObject *Sender)
{
    if(m_pkBookingSheetUtils->InstructorBooked())
    {
        if(QuickLessonBooking->ShowModal() == mrOk)
        {

        }
    }
    else
    {
        Application->MessageBox("No instructor is set, you cannot book a lesson here.\nAdmin users, to add an instructor, move selection to the box above, right click and add an instructor.", "No Instructor Set", MB_ICONINFORMATION|MB_OK);
    }
}
//---------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::instructorPopupPopup(TObject *Sender)
{
    SetInstructor->Enabled = true;
    ChangeInstructor->Enabled = true;
    ClearInstrcutor->Enabled = true;

    if(m_pkBookingSheetUtils->InstructorBooked())
    {
        ChangeInstructor->Enabled = true;
        ClearInstrcutor->Enabled = true;
    }
    else
    {
        ChangeInstructor->Enabled = false;
        ClearInstrcutor->Enabled = false;
    }
}
//---------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::lessonPopupPopup(TObject *Sender)
{
    if(m_pkBookingSheetUtils->LessonBooked())
    {
        CreateLesson->Enabled = false;
    }
    else
    {
        CreateLesson->Enabled = true;
    }

    if(LessonXSG->Cells[LessonXSG->Col][LessonXSG->Row] == "")
    {
        EditLesson->Enabled = false;
        RemoveLesson->Enabled = false;
    }
    else
    {
        EditLesson->Enabled = true;
        RemoveLesson->Enabled = true;
    }
}
//---------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::AddnewRowClick(TObject *Sender)
{
    LessonXSG->RowCount += 2;
    m_pkBookingSheetUtils->SetRowHeights();
}
//---------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::RemoveRow1Click(TObject *Sender)
{
    int ans = Application->MessageBox("If you removed this row, lessons can not be booked on them.", "Do you want to remove the selected instructor row?", MB_YESNO|MB_ICONQUESTION);
    if(ans == ID_YES)
    {
        LessonXSG->RowCount -= 2;
        m_pkBookingSheetUtils->SetRowHeights();
    }
}
//---------------------------------------------------------------------------

void __fastcall TLessonBookingSheet::LessonXSGStartDrag(TObject *Sender, TDragObject *&DragObject)
{
//
}
//---------------------------------------------------------------------------


