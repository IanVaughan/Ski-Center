//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "quickLessonBookingSrc.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "XStringGrid"
#pragma resource "*.dfm"
TQuickLessonBooking *QuickLessonBooking;
//---------------------------------------------------------------------------

__fastcall TQuickLessonBooking::TQuickLessonBooking(TComponent* Owner) : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TQuickLessonBooking::CancelBTNClick(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------

void __fastcall TQuickLessonBooking::FormShow(TObject *Sender)
{
    lessonFormCB->ItemIndex = 0;
    lessonTypeCB->ItemIndex = 0;
    custNumAdultCB->ItemIndex = 0;
//    custNumChildCB->ItemIndex = 0;
}
//---------------------------------------------------------------------------


void __fastcall TQuickLessonBooking::custNumAdultCBChange(TObject *Sender)
{
    int count = custNumAdultCB->Text.ToIntDef(0);// + custNumChildCB->Text.ToIntDef(0);
    if(count >0)
        customersOnLessonGrid->RowCount = count+1;
    else
        customersOnLessonGrid->RowCount = 2;
}
//---------------------------------------------------------------------------

void __fastcall TQuickLessonBooking::custNumChildCBChange(TObject *Sender)
{
    custNumAdultCBChange(this);
}
//---------------------------------------------------------------------------

void __fastcall TQuickLessonBooking::SaveBTNClick(TObject *Sender)
{
    ModalResult = mrOk;
}
//---------------------------------------------------------------------------

