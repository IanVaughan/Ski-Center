//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "instructorSrc.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TinstructorForm *instructorForm;
//---------------------------------------------------------------------------

__fastcall TinstructorForm::TinstructorForm(TComponent* Owner) : TForm(Owner)
{
}
//---------------------------------------------------------------------------

String TinstructorForm::GetSelectedName()
{
    int sel = instructorList->ItemIndex;
    return instructorList->Items->Strings[sel];
}
// -----------------------------------------------------------------------------

void __fastcall TinstructorForm::instructorListClick(TObject *Sender)
{
    if(instructorList->ItemIndex > -1)
    {
        SaveAsBTN->Enabled = true;
        SaveOnceBTN->Enabled = true;
    }
    else
    {
        SaveAsBTN->Enabled = false;
        SaveOnceBTN->Enabled = false;
    }
}
//---------------------------------------------------------------------------

#include "InstructorNameSrc.h"
void __fastcall TinstructorForm::AddMIClick(TObject *Sender)
{
    //add
    if(InstructorNameEdit->ShowModal() == mrOk)
    {
        instructorList->Items->Add(InstructorNameEdit->nameEdit->Text);
    }
}
//---------------------------------------------------------------------------

void __fastcall TinstructorForm::EditMIClick(TObject *Sender)
{
    //edit
    int sel = instructorList->ItemIndex;
    InstructorNameEdit->nameEdit->Text = GetSelectedName();
    if(InstructorNameEdit->ShowModal()== mrOk)
    {
        instructorList->Items->Delete(sel);
        instructorList->Items->Add(InstructorNameEdit->nameEdit->Text);
    }
}
//---------------------------------------------------------------------------

void __fastcall TinstructorForm::DeleteMIClick(TObject *Sender)
{
    //delete
    instructorList->Items->Delete(instructorList->ItemIndex);
}
//---------------------------------------------------------------------------

void __fastcall TinstructorForm::instructorListDblClick(TObject *Sender)
{
    SaveAsBTNClick(this);
}
//---------------------------------------------------------------------------


void __fastcall TinstructorForm::SaveOnceBTNClick(TObject *Sender)
{
    instructorList->Items->SaveToFile("Instructors\\Instructors.ins");
    //Close();
    ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TinstructorForm::SaveAsBTNClick(TObject *Sender)
{
    instructorList->Items->SaveToFile("Instructors\\Instructors.ins");
    //Close();
    ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TinstructorForm::FormShow(TObject *Sender)
{
    String filename = "Instructors\\Instructors.txt";

    bool yes = FileExists(filename);
    if(!yes)
    {
        Application->MessageBox("That Instructors file was not found, sorry!\nI have created a new blank one for you.", "File not found", MB_OK|MB_ICONERROR);
        //return false;
        instructorList->Items->SaveToFile(filename);
    }

    instructorList->Items->LoadFromFile(filename);
}
//---------------------------------------------------------------------------

void __fastcall TinstructorForm::PopupMenu1Popup(TObject *Sender)
{
    if(instructorList->ItemIndex == -1)
    {
        EditMI->Enabled = false;
        DeleteMI->Enabled = false;
    }
    else
    {
        EditMI->Enabled = true;
        DeleteMI->Enabled = true;
    }
}
//---------------------------------------------------------------------------

