//---------------------------------------------------------------------------
#ifndef helpH
#define helpH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class ThelpForm : public TForm
{
__published:	// IDE-managed Components
    TBitBtn *BitBtn1;
    void __fastcall BitBtn1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall ThelpForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE ThelpForm *helpForm;
//---------------------------------------------------------------------------
#endif
